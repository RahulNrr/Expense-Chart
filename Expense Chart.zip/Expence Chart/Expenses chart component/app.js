const first_amount = document.querySelector("#first_amount");
const second_amount = document.querySelector("#second_amount");
const third_amount = document.querySelector("#third_amount");
const fourth_amount = document.querySelector("#fourth_amount");
const fifth_amount = document.querySelector("#fifth_amount");
const sixth_amount = document.querySelector("#sixth_amount");
const seventh_amount = document.querySelector("#seventh_amount");

function mouseOver(first_amount) { first_amount.style.display = "block"; }

function mouseOut(first_amount) { first_amount.style.display = "none"; }


function mouseOver(second_amount) { second_amount.style.display = "block"; }

function mouseOut(second_amount) { second_amount.style.display = "none"; }

function mouseOver(third_amount) { third_amount.style.display = "block"; }

function mouseOut(third_amount) { third_amount.style.display = "none"; }

function mouseOver(fourth_amount) { fourth_amount.style.display = "block"; }

function mouseOut(fourth_amount) { fourth_amount.style.display = "none"; }

function mouseOver(fifth_amount) { fifth_amount.style.display = "block"; }

function mouseOut(fifth_amount) { fifth_amount.style.display = "none"; }

function mouseOver(sixth_amount) { sixth_amount.style.display = "block"; }

function mouseOut(sixth_amount) { sixth_amount.style.display = "none"; }

function mouseOver(seventh_amount) { seventh_amount.style.display = "block"; }

function mouseOut(seventh_amount) { seventh_amount.style.display = "none"; }